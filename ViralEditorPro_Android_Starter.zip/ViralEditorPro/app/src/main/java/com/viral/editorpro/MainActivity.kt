package com.viral.editorpro

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Transformer
import java.io.File
import java.io.FileInputStream

private val Ink = Color(0xFF10131C)
private val Panel = Color(0xFF1B2030)
private val Accent = Color(0xFF7C5CFC)
private val Muted = Color(0xFF9BA3B7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ViralEditorApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ViralEditorApp() {
    val context = LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var trimStart by remember { mutableFloatStateOf(0f) }
    var trimEnd by remember { mutableFloatStateOf(1f) }
    var exporting by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Pilih video untuk mulai mengedit") }
    var player by remember { mutableStateOf<ExoPlayer?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            videoUri = uri
            player?.release()
            player = ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(uri))
                prepare()
                playWhenReady = false
                addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        if (playbackState == Player.STATE_READY) {
                            durationMs = duration.coerceAtLeast(0L)
                            trimEnd = 1f
                        }
                    }
                })
            }
            status = "Video siap diedit"
        }
    }

    DisposableEffect(Unit) {
        onDispose { player?.release() }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Ink,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("VIRAL EDITOR PRO", fontWeight = FontWeight.Black, fontSize = 17.sp)
                            Text("Studio video gratis", color = Muted, fontSize = 11.sp)
                        }
                    },
                    actions = {
                        TextButton(
                            enabled = videoUri != null && !exporting,
                            onClick = {
                                val uri = videoUri ?: return@TextButton
                                val startMs = (trimStart * durationMs).toLong()
                                val endMs = (trimEnd * durationMs).toLong()
                                if (endMs <= startMs) {
                                    Toast.makeText(context, "Atur bagian video terlebih dahulu", Toast.LENGTH_SHORT).show()
                                    return@TextButton
                                }
                                exporting = true
                                status = "Sedang mengekspor video..."
                                val input = MediaItem.Builder()
                                    .setUri(uri)
                                    .setClippingConfiguration(
                                        MediaItem.ClippingConfiguration.Builder()
                                            .setStartPositionMs(startMs)
                                            .setEndPositionMs(endMs)
                                            .build()
                                    ).build()
                                val edited = EditedMediaItem.Builder(input).build()
                                val out = File(context.cacheDir, "viral_export_${System.currentTimeMillis()}.mp4")
                                val transformer = Transformer.Builder(context)
                                    .addListener(object : Transformer.Listener {
                                        override fun onCompleted(
                                            composition: androidx.media3.transformer.Composition,
                                            exportResult: androidx.media3.transformer.ExportResult
                                        ) {
                                            try {
                                                val values = ContentValues().apply {
                                                    put(MediaStore.Video.Media.DISPLAY_NAME, "ViralEditor_${System.currentTimeMillis()}.mp4")
                                                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                                                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ViralEditor")
                                                }
                                                val dest = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                                                if (dest != null) {
                                                    context.contentResolver.openOutputStream(dest)?.use { output ->
                                                        FileInputStream(out).use { it.copyTo(output) }
                                                    }
                                                    status = "Selesai! Video tersimpan di Movies/ViralEditor"
                                                } else status = "Ekspor selesai, tetapi gagal menyimpan ke galeri"
                                            } catch (e: Exception) {
                                                status = "Gagal menyimpan: ${e.localizedMessage}"
                                            } finally {
                                                out.delete()
                                                exporting = false
                                            }
                                        }
                                        override fun onError(
                                            composition: androidx.media3.transformer.Composition,
                                            exportResult: androidx.media3.transformer.ExportResult,
                                            exportException: androidx.media3.transformer.ExportException
                                        ) {
                                            exporting = false
                                            status = "Ekspor gagal: ${exportException.localizedMessage}"
                                        }
                                    }).build()
                                transformer.start(edited, out.absolutePath)
                            }
                        ) { Text("EKSPOR", color = Color.White, fontWeight = FontWeight.Bold) }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink)
                )
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(
                    Modifier.fillMaxWidth().height(360.dp)
                        .background(Color.Black, RoundedCornerShape(18.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (videoUri != null && player != null) {
                        AndroidView(
                            factory = { ctx ->
                                PlayerView(ctx).apply {
                                    useController = true
                                    player = player
                                    layoutParams = FrameLayout.LayoutParams(-1, -1)
                                }
                            },
                            update = { it.player = player },
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Movie, null, tint = Muted, modifier = Modifier.size(56.dp))
                            Spacer(Modifier.height(10.dp))
                            Text("Pratinjau video", color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text("Impor video dari galeri", color = Muted, fontSize = 12.sp)
                        }
                    }
                }

                Button(
                    onClick = { picker.launch("video/*") },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent)
                ) {
                    Icon(Icons.Default.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (videoUri == null) "PILIH VIDEO" else "GANTI VIDEO")
                }

                SectionTitle("POTONG VIDEO")
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Awal: ${(trimStart * durationMs / 1000).toInt()} dtk", color = Muted, fontSize = 12.sp)
                        Slider(
                            value = trimStart,
                            onValueChange = { trimStart = it.coerceAtMost(trimEnd - 0.01f) },
                            valueRange = 0f..1f,
                            enabled = videoUri != null
                        )
                        Text("Akhir: ${(trimEnd * durationMs / 1000).toInt()} dtk", color = Muted, fontSize = 12.sp)
                        Slider(
                            value = trimEnd,
                            onValueChange = { trimEnd = it.coerceAtLeast(trimStart + 0.01f) },
                            valueRange = 0f..1f,
                            enabled = videoUri != null
                        )
                        Text("Atur titik awal dan akhir, lalu tekan EKSPOR.", color = Muted, fontSize = 11.sp)
                    }
                }

                SectionTitle("MENU EDITING")
                val tools = listOf(
                    "Audio & Musik" to Icons.Default.MusicNote,
                    "Teks & Subtitle" to Icons.Default.TextFields,
                    "Filter & Warna" to Icons.Default.Tune,
                    "Kecepatan Video" to Icons.Default.Speed,
                    "Transisi" to Icons.Default.AutoAwesome,
                    "Overlay & Layer" to Icons.Default.Layers,
                    "Rasio 9:16 / 16:9" to Icons.Default.Crop,
                    "Keyframe" to Icons.Default.Timeline
                )
                tools.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        pair.forEach { (label, icon) ->
                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = Panel)
                            ) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(icon, null, tint = Accent)
                                    Text(label, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                    Text("Tahap berikutnya", color = Muted, fontSize = 10.sp)
                                }
                            }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (exporting) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        else Icon(Icons.Default.Info, null, tint = Accent)
                        Spacer(Modifier.width(10.dp))
                        Text(status, color = Muted, fontSize = 12.sp)
                    }
                }
                Text(
                    "Viral Editor Pro • Versi awal 0.1.0",
                    color = Muted, fontSize = 10.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
}
