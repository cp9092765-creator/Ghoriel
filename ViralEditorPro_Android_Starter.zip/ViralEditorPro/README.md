# Viral Editor Pro — Android starter project

Versi awal: 0.1.0

## Fitur yang sudah ada
- Antarmuka editor Android berbasis Jetpack Compose.
- Memilih video dari galeri.
- Pratinjau/pemutaran video.
- Memilih titik awal dan akhir untuk pemotongan.
- Ekspor hasil potongan MP4 ke `Movies/ViralEditor` tanpa watermark.

## Fitur yang belum dibuat
Menu Audio, Teks/Subtitel, Filter, Kecepatan, Transisi, Overlay, rasio kanvas, keyframe, dan multi-track masih berupa rancangan antarmuka. Fitur-fitur itu perlu dikembangkan bertahap.

## Cara membuka dan membuat APK
1. Instal Android Studio di komputer.
2. Ekstrak ZIP ini.
3. Android Studio > Open > pilih folder `ViralEditorPro`.
4. Tunggu Gradle Sync selesai dan izinkan pengunduhan dependensi.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug akan tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

Persyaratan: Android Studio dengan JDK 17 dan Android SDK Platform 35.

## Catatan
Proyek ini adalah fondasi awal, bukan salinan CapCut dan belum setara CapCut Pro. Kompilasi APK membutuhkan Android SDK/Gradle di komputer. Kinerja ekspor bergantung pada perangkat dan format video sumber.
